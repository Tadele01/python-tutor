from setuptools import setup
setup(
	name = 'funtions',
	version = '1.0',
	description = 'The Tadele Yednkachw python search tools',
	author = 'Tadele Yednkachw',
	author_email = 'tadeleyednkachw@gmail.com',
	url = 'tdy.com',
	py_modules = ['funtions'],
      )